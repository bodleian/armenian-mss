
The 'working' folder has 3 sub-folders where I (James Cummings) was doing various conversion work.
- [old](old/) contains the original files I was given
- [new](new/) contains the deduplicated and normalized files ready for conversion. 
- [draft-updated](draft-updated/) contains the updated files



